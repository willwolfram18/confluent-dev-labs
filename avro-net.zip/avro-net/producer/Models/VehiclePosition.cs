using solution.model;

namespace Models
{
    public class VehiclePosition
    {
        public PositionValue VP { get; set; }
    }
}